############################
### paste() and paste0() ###
############################

# Always return a character vector.

x <- LETTERS[1:10]
y <- seq(1,10);

paste(x);
paste(y);   # A character vector.
typeof(paste(y));

paste(x, y);
paste0(x, y);  # No separator.

y <- seq(1,5);
paste0(x, y);  # y is shorter than x, hence recycling.

z <- c("-rep1", "-rep2");
paste0(x, y, z); # z is also recycled as needed.


# You can "collapse" the resulting vector to a single
# string.

paste0(x, y, collapse = " ");

#################################
### Do the following yourself ###
#################################

mtl <- LETTERS[1:8]
mtn <- seq(1,12)

# Using rep() and paste0() and the two vectors made
# above, make a vector of all the addresses on a 96
# well microtitre plate.

# A1 to A12 then B1 to B12 ... H1 to H12.

# Hint: call to rep() will go inside the call to paste0()
# and will also use the named argument "each".
