######################
### apply() et al. ###
######################

### apply() ###
x <- runif(60, min = 20, max = 30)
dim(x) <- c(15, 4);
x

apfun <- function(arg1) {
return(arg1 - mean(arg1));
}
apply(x, 1, apfun);
t(apply(x, 1, apfun));

y <- cbind(x, t(apply(x, 1, apfun)));
y


### lapply() and sapply() ###

strepgenes <- read.csv("data/strepGenes.txt", header = F,
                       stringsAsFactors = F);

canoname <- function(x) {
spl <- strsplit(x, "\\s+", perl = TRUE);
cano <- spl[[1]][!grepl("SVEN_|SVEN15_|vnz_|^-$",
                        spl[[1]], perl = TRUE)];
return(cano);
}

lapply(strepgenes[[1]], canoname);

unlist(lapply(strepgenes[[1]], canoname));

sapply(strepgenes[[1]], canoname);

unname(sapply(strepgenes[[1]], canoname));

temp <- cbind(strepgenes,
cano = unname(sapply(strepgenes[[1]], canoname)));

### tapply() ###

# We saw this when doing Factors.
