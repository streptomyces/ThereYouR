######################
### apply() et al. ###
######################

### apply() ###
x <- runif(60, min = 20, max = 30)
dim(x) <- c(15, 4);
x

apfun <- function(arg1) {
return(arg1 - mean(arg1));
}
apply(x, 1, apfun);
t(apply(x, 1, apfun));

y <- cbind(x, t(apply(x, 1, apfun)));
y


### lapply() and sapply() ###

strepgenes <- read.csv("data/strepGenes.txt", header = F,
                       stringsAsFactors = F, col.names =
                       c("all.names"));

x <- head(strepgenes, 1); # for explaining
str_split(x$all.names, "\\s+"); # for explaining


canoname <- function(x) {
spl <- str_split(x, "\\s+");
splitvec <- spl[[1]];
cano <- splitvec[!grepl("SVEN_|SVEN15_|vnz_|^-$",
    splitvec, perl = TRUE)];
return(cano);
}

lapply(strepgenes$all.names, canoname);

unlist(lapply(strepgenes$all.names, canoname));

sapply(strepgenes$all.names, canoname);

unname(sapply(strepgenes$all.names, canoname));

temp <- cbind(strepgenes,
cano = unname(sapply(strepgenes$all.names, canoname)));

### tapply() ###

# We saw this when doing Factors.
