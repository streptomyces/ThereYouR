##############################
### Scope and Environments ###
##############################

# Lexical scope: Functions are evaluated in the environment
# in which they are defined.
#
# The environment provides values for any unbound symbols in
# a function when the function is evaluated.

funcgen <- function(g = 9.8) {
  time2ground <- function(height = 1, initial = 0) {
    fvsq <- (initial ** 2) + (2 * g * height);
    final = sqrt(fvsq);
    t2g = (final - initial) / g;
    return(t2g);
  }
  return(time2ground);
}

ttg.earth <- funcgen(9.8);  # function
ttg.mars <- funcgen(3.72);  # function

ttg.earth(10);
ttg.mars(10);

environment(ttg.earth);
environment(ttg.mars);

ls(envir = environment(ttg.mars));
get("g", envir = environment(ttg.mars));
get("g", envir = environment(ttg.earth));

parent.env(environment(ttg.earth));
parent.env(environment(ttg.mars));
environment(funcgen);

# Current session environment is available in .GlobalEnv

# The effective environment is a nesting of environments.

parent.env(.GlobalEnv);
parent.env(parent.env(.GlobalEnv));
parent.env(parent.env(parent.env(.GlobalEnv)));

#################################
### The search path. search() ###
#################################

time2ground(10);

search();

attach(environment(ttg.earth));

search();

time2ground(10);

g

ls()

