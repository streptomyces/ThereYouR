########################
### Plotting devices ###
########################

### Plotting Devices ###

# Plotting functions such as plot() draw to a plotting
# device.

# If no plotting device(s) exists then one of the
# default type is created.

# Devices are identified by numbers.

# At any time you have only one active plotting device
# although more may be in existence.

# dev.* functions control plotting devices.

# e.g. dev.new() will give you a new plotting device of
# the default type.

# e.g. dev.set() is called with an argument which is the
# device number you wish to make active.

# You can use windows() to get a plotting device for
# your current display. On Linux this command is x11()
# and on OSX it is quartz().

# dev.off() can be used to close any plotting device. If
# no argument is given, the active plotting device is
# closed.

# graphics.off() is used to close all plotting devices.

# It is important to close devices if they are connected
# to a file such as a png or a jpeg file.

#################################
### Do the following yourself ###
#################################

# 1. x <- seq(1, 1e4, by = 5)

# 2. y <- log10(x)

# 3. Get a new plotting device by using dev.new()

# 4. Get a new plotting device by using windows()

# 5. Examine the output of dev.list()

# 6. plot(x,y)

# 7. Use dev.set() to make the other plotting device
# active.

# 8. Again, plot(x,y)

# 9. Use dev.off() to close the active device.

# 10. Use graphics.off() to close all plotting devices.
