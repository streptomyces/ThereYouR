##########################
### NA, NaN, Inf, NULL ###
##########################

x <- seq(from = 2, to = 10, by = 2);
x <- c(x, NA);
x;
mean(x);
sum(x);
sd(x);

####################################################

books <- c("Practical Ethics", "A Theory of Justice",
           "The Wealth of Nations", "What Money Can't Buy",
           "Jonathan Livingston Seagull");

authors <- c("Peter Singer", "John Rawls", NA,
             "Michael Sandel", "Richard Bach");

sold <- c(0.6, 0.2, NA, 0.7, 0.7);

ba <- data.frame(books = books, authors = authors, sold = sold);

ba

# What is the class of NA?

class(NA);
class(ba[3, "authors"]);
class(ba[3, "sold"]);

#################################
### Do the following yourself ###
#################################

# 1. Call the mean(), sum() and sd() functions as above
# but with the additional named argument "na.rm = TRUE"
# e.g. sum(x, na.rm = TRUE)

# 2. Examine the output of summary(x).

# 3. Examine the output of is.na(x).
 
### Inf and -Inf are reserved words in R.

#################################
### Do the following yourself ###
#################################

# 1. Examine the output of 2/0

# 2. Examine the output of -2/0

# 3. Examine the output of is.finite(2/0)

# 4. Examine the output of is.finite(0/2)

# 5. Store the output of 2/0 in i.

# 6. Test that i is infinite.


### NaN (Not a Number) is a reserved word in R.

0/0
x <- log2(-10)
x

# 2. Examine the output of is.nan(x).

# 3. Examine the output of is.na(x).

### NULL

# Complete absence of any value or object.

######################################################
### Think about the output of the following blocks ###
######################################################

is.null(0)

retval <- cat("Just some text\n");
retval

is.null(0/0)

is.null(authors[3]);
