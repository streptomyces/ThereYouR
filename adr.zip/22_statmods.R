###############################
### Statistical Models in R ###
###############################

# Normal
# rnorm(): random generation function
# pnorm(): probability density function
# dnorm(): density function
# qnorm(): quantile function
# Similarly for uniform, binomial, gamma, t, etc.

### Example: Normal distribution.

x <- rnorm(500, mean = 15, sd = 5);

pnorm(35, mean = 15, sd = 5);  # P(X <= 35).

pnorm(35, mean = 15, sd = 5, lower.tail = FALSE);  # P(X > 35)

dnorm(seq(1,10), mean = 5, sd = 1)

#################################
### Do the following yourself ###
#################################

# 1. Generate 2000 normally distributed random numbers
# from a population where the mean is 18 and standard
# deviation is 3 and keep them in a vector named x.

# 2. Confirm that x has 2000 elements without listing
# them all.

# 3. Find the minimum, maximum, mean and median of x.

# 4. The function for standard deviation is sd(). Use this
# function to find the standard deviation of x. Should
# be approximately 3.

# 5. The function for square root is sqrt(). Standard
# error of the mean (SEM) is calculated as the SD
# divided by the square root of the sample size. Without
# using any variable other than x, find the SEM. Should
# be approximately 0.06.
