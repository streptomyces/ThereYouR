###########################
### Sorting a data frame ###
############################

# Three related functions: sort(), order(), rank()

### sort() ###

set.seed(56)
x <- as.integer(runif(10, 1, 50) * 7)
x
sx <- sort(x)
sx

### The order of numbers in x itself is unchanged by the sort
### operation. sx is a new vector.

### rank() ###

rx <- rank(x)

rx

### order() ###

ox <- order(x);

ox;

# For the same vector x, compare the output of rank() and order()
# x, ox and rx.


# To sort a data frame by some column, we cannot simply use
# sort().

# 1. First we get the order of rows by calling order() on the
#    column we wish to sort by.

# 2. Then we use the order to sort the entire data frame.

ordvec <- order(data$logFC);
sdata <- data[ordvec, ];
head(sdata);
tail(sdata);

#################################
### Do the following yourself ###
#################################

# Run the following block if you have lost or broken the
# data frame named "data" made earlier.
data <- read.csv("data/expression.csv", header = TRUE, row.names = 1)
data$logFC <- data$treatment - data$control;
temp <- read.csv("data/products.csv", row.names = 1,
                    stringsAsFactors = FALSE);
data$product <- temp[rownames(data), "product"]


# 1. It would be more meaningful to sort data on absolute log
#    fold change and to have the highest change at the top.

# 2. The function for getting absolute values is abs().

# 3. Consult the help for order() to find the named argument you
#    need to use to order in decreasing order.

# 4. Now sort data by decreasing value of absolute logFC.



# If you have ties in the column you are sorting by then you
# might wish to use a second column to break the ties.
 
# Below, I am copying data to data2 and setting some control
# values to 50.

data2 <- data;
data2[c("SCO0500", "SCO0501", "SCO0502", "SCO0503") , "control"] <- 50;

# Suppose we wish to sort this data frame in decreasing order by
# the control expression but in increasing order by the absolute
# logFC.

ordvec <- order(-data2$control, abs(data2$logFC))
sdata2 <- data2[ordvec, ]
head(sdata2)

###################
### dplyr style ###
###################

stib <- arrange(tib, logFC);
stib

stib <- arrange(tib, desc(abs(logFC)));
stib

tib2 <- as_tibble(data2, rownames = "gene");
stib2 <- arrange(tib2, desc(control), abs(logFC));
stib2

