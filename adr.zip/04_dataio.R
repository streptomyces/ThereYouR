################################
### Reading and Writing Data ###
################################

# Most analyses in R start with reading some data into R.

# Data gets read into "objects" which are structured
# collections of the more fundamental data types.

# Objects belong to "classes". Several classes are defined
# in R.

# It is possible to make your own classes but we will not be
# doing so. The ones provided are sufficient for what we do.

# Classes range in complexity and flexibility.

# Reading data from a text file.
vnz.df <- read.csv("data/vnz_genes.csv", header = T,
stringsAsFactors = F)

# Writing data to a text file.
write.csv(vnz.df, "out/vnz_genes.csv", quote = F,
row.names = F);

### Tidyverse style ###

# Reading data from a text file.
vnz.tib <- read_csv("data/vnz_genes.csv");

# Writing data to a text file.
write_csv(vnz.tib, "out/vnz_genes.csv",
quote_escape = "none")

### Things to be careful about ###

# Don't ignore error messages.
# Ensure you have read in all the data by counting lines.
# Confirm column types are what they should be.
# Column names may have been changed by R.

