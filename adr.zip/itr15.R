#############
### Lists ###
#############

# Lists are generic vectors.

# Generally when we say "vector" we mean "atomic
# vectors".

# Individual elements of a list can contain any type of
# R object of any complexity, including other lists.

# This allows for the creation of objects of arbitrary
# complexity.

# Functions returning a lot of related information
# often return their results as lists.

x <- seq(1,20, by = 5);
y <- c("one", "two", "three");
i <- list(x, y);

i;
i[1];   # list
i[[1]]; # vector
class(i[1]);
class(i[[1]]);

names(i) <- c("numbers", "strings");

i["numbers"];
i[["numbers"]];
names(i);


j <- list(numbers = x, strings = y, serial = seq(1,20));

j[["serial"]][3:10];
j$serial;
j$serial[15:20];

################
### unlist() ###
################

unlist(j); # all atomic components of j in a vector
# Notice coercion above.

k <- list(x = x, y = seq(200, 400, by = 10));
k
unlist(k)
class(unlist(k))

#################################
### Do the following yourself ###
#################################

# 1. Make a vector of characters A to N by appropriately
# subsetting LETTERS.

# 2. Make a vector of integers from 10 to 20.

# 3. Make a list li, with two named elements, alpha
# containing the vector made in step 1 above and, beta
# containing the vector made in step 2 above.

# 4. Display the names of the elements in the list made
# above.

# 5. In one step, extract the fourth element from the
# alpha member of li.
