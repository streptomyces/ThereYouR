##############################
### Conditional subsetting ###
##############################

# Run the following block if you have lost or broken the
# data frame named "data" made earlier.
data <- read.csv("data/expression.csv", header = TRUE,
                 row.names = 1)
data$logFC <- data$treatment - data$control;
temp <- read.csv("data/products.csv", row.names = 1,
                    stringsAsFactors = FALSE);
data$product <- temp[rownames(data), "product"]


head(data);
nrow(data)


up1.tf <- data$logFC >= 1;
up1 <- data[up1.tf, ];
nrow(up1);
head(up1)

up1c7.tf <- data$logFC >= 1 & data$control >= 7 ;
up1c7 <- data[up1c7.tf, ];
nrow(up1c7)
head(up1c7)

### dplyr style ###

up1c7.tib <- filter(tib, logFC > 1 & control >= 7);

