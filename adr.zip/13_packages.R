################
### Packages ###
################

# R classes and functions written by others for you to
# use.

# Provide namespaces which roughly translate into
# environments on the search() hierarchy thus avoiding
# symbol clashes.

# Packaged to be loaded on demand to minimise resource
# use.

# When you load a package additional functions defined
# in the package become available for you to use.
# Sometimes existing functions might be over-ridden.

# CRAN has a repository of R packages.

# Bioconductor is a repository of packages for
# bioinfomatics. Bioconductor has its own installer.

### Installing edgeR ###

# Check before doing the below.

if (!requireNamespace("BiocManager", quietly = TRUE))
    install.packages("BiocManager")
BiocManager::install("edgeR")

#################################
### Using packages. library() ###
#################################

library("edgeR");

# Load the namespace of the package with name
# ‘package’ and attach it on the search list.

# The reverse is

detach("package:edgeR", unload = TRUE)

# Sometimes you will see a function being called as

#        packagename::funcname()
# e.g.   readxl::read_excel()

# In such cases the package is loaded (into memory) but it
# is not attached to the search path. This is good for one
# time use of a function and to avoid namespace conflicts
# resulting in masking.

# Also good for accessing masked functions.

# e.g. stats::filter() to use the filter function in the
# stats package while it is masked by the one in dplyr
# package.
