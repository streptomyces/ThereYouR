##############################
### Attaching a data frame ###
##############################

# It is a convenience feature allowing you to refer to df$column
# as just column.


rm(list = ls());

control <- seq(1, 100);

df <- read.csv("data/expression.csv", row.names = "gene");

head(df);

attach(df);    # Note the warning following this command.

head(control);   # This control is not coming from the data frame df.

rm(control);

head(control);

search()

detach(df)

search()
