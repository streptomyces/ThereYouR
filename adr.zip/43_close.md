# Remarks

Like any other skill, the best way to maintain and
advance your R skills is by using it regularly. Try to get
together with a friend and use R regularly. 

It also helps to rule out easier alternatives such as MS
Excel. They are only superficially efficient.

Do not try to remember things. That is what computers are
for. Develop the skill to read documentation quickly. It
more important than you think. Not just in R.

Some things are easier done in a general purpose programming
language such as Perl or Python.

[R manuals webpage](https://cran.r-project.org/manuals.html)

[PDF of the Introduction to R book]
(https://cran.r-project.org/doc/manuals/r-release/R-intro.pdf)

[RNA-Seq data analysis using edgeR]
(https://f1000research.com/articles/5-1438)

There are some very good tutorials on YouTube.

