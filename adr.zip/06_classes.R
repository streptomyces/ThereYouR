###############
### Classes ###
###############

# Data structures with associated functions (methods).

# e.g. Some of the methods in the the class data.frame are

# [             [[            [[<-          [<-           $<-          
# aggregate     anyDuplicated as.data.frame as.list       as.matrix    
# by            cbind         coerce        dim           dimnames     
# dimnames<-    droplevels    duplicated    edit          format       

# A class is a recipe for making objects and a "constructor"
# method is usually available but often you will bring them
# into existence simply by assignment.

### Classes provided by base R ###

## Vector Classes ##
# character
# complex
# double
# expression
# integer
# list
# logical
# numeric
# raw


# function
# NULL

