#############################
### Reading documentation ###
#############################

help("seq")
help("plot")

# In Rstudio the actual text appears in the "Help" tab.


# Below shows all the packages which have anything to do
# with "sequence".

help.search("sequence")

### Sometimes there is runnable example code. ###

example("hist")

### There are lots of bundled example data sets ###

data() # lists available data sets.

data("cars") # loads the named data set.
ls()
head(cars)

### Finding methods ###

# All definitions for a generic method in the search
# path.

methods("plot"); # plot is a generic function.
?plot.histogram

# All methods available in a class.
methods(class = "histogram");
methods(class = "data.frame");

# Packages are not the same as classes. Classes are
# defined in packages and more than one may be defined
# in one package.

# Before calling library("edgeR");

library(help = "edgeR")

# Above should tell you what classes and functions are
# available in the edgeR package. Then you can see
# the help for those as below.

help("DGEList", package = "edgeR")
help("DGEList-class", package = "edgeR")


# After calling library("edgeR");
library("edgeR");
methods(class = "DGEList");
help("DGEList-class")
help("DGEList")
help("subsetting", package = "edgeR");

methods(class = "DGEGLM");
help("DGEGLM-class")
help("DGEGLM")
