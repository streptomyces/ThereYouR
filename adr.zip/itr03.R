###############
### Classes ###
###############

# Data structures with associated functions (methods).

# e.g. the class data.frame has the following methods.

# [             [[            [[<-          [<-           $<-          
# aggregate     anyDuplicated as.data.frame as.list       as.matrix    
# by            cbind         coerce        dim           dimnames     
# dimnames<-    droplevels    duplicated    edit          format       
# formula       head          initialize    is.na         Math         
# merge         na.exclude    na.omit       Ops           plot         
# print         prompt        rbind         row.names     row.names<-  
# rowsum        show          slotsFromS3   split         split<-      
# stack         str           subset        summary       Summary      
# t             tail          transform     type.convert  unique       
# unstack       within 

# A class is a recipe for making objects and a "constructor"
# method is usually available.
