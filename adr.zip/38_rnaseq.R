###############
### RNA-Seq ###
###############

# Use of the package edgeR to analyse RNASeq data

# edgeR is a Bioconductor package you can read about it
# here
# https://www.bioconductor.org/packages/release/bioc/html/edgeR.html
# Start with the User Guide. You may have to read the
# Reference Manual to do somethings.

# Using these two it is possible to develop a sequence
# of R commands which will do the analysis you desire on
# the data you have. This is a general pattern in
# Bioconductor packages.

### The experiment ###

# Antibiotic producing Streptomycetes often encode for more
# than one antibiotic but only one is expressed. Often, if
# this one is deleted another gene cluster will become
# activated and the organism will produce a different
# antibiotic.
 
# In this experiment we want to find out what genes are
# activated when the gene cluster producing the major
# antibiotic is deleted.
 
# dClus is the strain in which the cluster has been deleted.
# WT is the wild type strain.

# The reference genome is that of the wild type strain.

## Subread ##

# subread-buildindex make index for the reference genome.
# subread-align to align reads in fastq files to the index.
# featureCounts to get a table of number of reads mapping to
# each gene in the reference genome.

# Below are the columns in featcounts.tsv.

# 0	Geneid
# 1	Chr
# 2	Start
# 3	End
# 4	Strand
# 5	Length
# 6	dClus.d5.1
# 7	dClus.d5.2
# 8	dClus.d5.3
# 9	dClus.d2.1
# 10	dClus.d2.2
# 11	dClus.d2.3
# 12	WT.d5.1
# 13	WT.d5.2
# 14	WT.d5.3
# 15	WT.d2.1
# 16	WT.d2.2
# 17	WT.d2.3


### Analysis in R ###

# Read in the counts.
rdf <- read.delim("data/featcounts.tsv", row.names = "Geneid");
gene.lengths <- rdf[, "Length"];
names(gene.lengths) <- rownames(rdf);

# Delete
st.deleted <- seq(6650, 6690);
st.deleted <- str_c("Stri_", st.deleted);
rdf[st.deleted, ];



x <- rdf[, 6:ncol(rdf)];

# Reorder the columns so that replicates are next to each other.
cn <- colnames(x);
socn <- sort(cn);
socn;
x <- x[, socn];

# Groups
samp <- c("d2", "d5", "w2", "w5"); # needed later to make design.
group <- factor(rep(samp, each = 3))

# DGEList
y <- DGEList(counts = x, group = group);

# Filter out low counts. Then I also filter out
# all the RNAs. 
keep <- filterByExpr(y)
keep[str_detect(names(keep), "RNA")] <- F;

table(keep);
keep[!keep];

# help(subsetting, package = edger) to understand the line below.
y <- y[keep,,keep.lib.sizes=FALSE]

# Read products from 2 column file into data frame products.
# Add gene lengths and products to y$genes dataframe.
products <- read.delim("data/gene_products.tsv", stringsAsFactor = F,
header = T, row.names = 1);

y$genes <- data.frame(Length = gene.lengths[rownames(y)],
Product = products[rownames(y), "Product"]);

# Normalisation factors
y <- calcNormFactors(y)

#################################
### Do the following yourself ###
#################################

# 1. Examine the output of methods(class = class(y))

# 2. Amongst a lot of other things, the above will show
# you methods named rpkm() and rpkmByGroup()

# 4. Now use rpkmByGroup() to get the RPKMs and write them
# out to a tsv file. You will need as_tibble() here.


###############################
### Differential Expression ###
###############################

# Model matrix and design.
design <- model.matrix(~0+group, data = y$samples)
colnames(design) <- samp;

# Estimate dispersion and then get fit (glmQLFit()).
y <- estimateDisp(y,design)
fit <- glmQLFit(y, design)

# Contrasts we are interested in (makeContrasts()).
st.contrasts = makeContrasts(
day2=d2-w2,
day5=d5-w5,
levels = colnames(design)
);

# Test (glmQLFTest());
qlf <- glmQLFTest(fit, contrast = st.contrasts)

# Toptags (topTags) and output.
outlist = list();
for(rdc in colnames(st.contrasts)) {
qlf <- glmQLFTest(fit, contrast = st.contrasts[, rdc])
qtt = topTags(qlf, n = nrow(y), sort.by = "PValue")
outlist[[rdc]] <- qtt$table
}

names(outlist)

outdir <- c("out");
for(cname in names(outlist)) {
odf <- outlist[[cname]];
ofn <- file.path(outdir, str_c(cname, "_DGE.txt"));
otib <- as_tibble(odf, rownames = "Gene");
write_tsv(otib, ofn, quote_escape = "none");
}




# Collecting the RPKMs of the most highly changed genes
 
# "wt.hfq.rpkm" is a matrix. "de.table" is a data frame.
# "de.table" is ordered such that the most significantly
# changed genes are at the top.
 
# How will you get the RPKMs of the 30 most
# significantly changed genes?
 
#################################
### Do the following yourself ###
#################################

# 1. From de.table get a vector v, of the first 30 row
# names.

# 2. Create top30.rpkm by subscripting wt.hfq.rpkm to
# get the rows in vector v made above and all columns.

##################
### Why logFC? ###
##################

# Linear scale is asymmetric.

# Two fold up-regulation is 2

# Two fold down-regulation is 0.5

# So the entire down-regulation side is squeezed between
# 0 and 1.

plot(de.table$logFC, pch = 20)
plot(2**(de.table$logFC), pch = 20)

lfc <- sample(de.table$logFC, length(de.table$logFC));
plot(lfc, pch = 20)
plot(2**(lfc), pch = 20)

# Table of linear to log2 values.
x <- c(seq(2,16), seq(20, 200, by = 20));
lx <- log2(x);
lin2log <- data.frame(x = x, log2.x = lx)
lin2log

# Table of log2 to linear values
log2lin <- data.frame(log2.x = seq(0, 10, by = 0.5),
                      x = 2**(seq(0,10, by = 0.5))
                      );
log2lin


# Keep the following in mind when working with logFC and
# linearFC.

# 1. You cannot take the log of a negative number.

# 2. Log of numbers less than 1 is negative.

# 3. Log of 1 is zero.

# 4. Log of zero is -Inf.

# 5. Raise the base to the logFC value to get the linear
# fold change.
