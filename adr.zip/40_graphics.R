#####################
### Base graphics ###
#####################

# Several commands, plot(), boxplot(), points(), lines(),
# abline() and several others.

# plot() is usually the starting function call.

# points(), lines(), abline() etc. can add to the plot
# initially made by plot.

# plot() can behave differently depending upon what
# arguments are passed to it.

graphics.off()
x <- rnorm(1000, mean  = 20, sd = 2);
plot(x);
boxplot(x);

m <- matrix(x, nrow = 200, ncol = 5);
plot(m[,1], m[,2]);

plot(m[,1], m[,3]);

boxplot(m)
#################################
### Plotting parameters par() ###
#################################

# e.g. colour, title, margins, plots per device, font
# sizes, etc.

# The function par() is used to set the plotting
# parameters.

# Calls to par() affect the active plotting device.

# Calls to par() may be made before, in-between and
# along with calls to plot(), points, lines() etc.

# The changed parameters affect all subsequent commands
# acting on the plot.

# help("par") lists a lot of parameters that can be set
# via par().

graphics.off();
par(mfrow = c(1,2), bty = "n");
x <- rnorm(50);
par(pch = c(19));
plot(x);
# Examine the plot here and then proceed.
par(pch = c(20), col = "red");
plot(x, main = "This time in red")


#################################
### Do the following yourself ###
#################################

# 1. Get a new plotting device so that all parameters
#    are at their default values.

# 2. x <- seq(2,100, by = 2).

# 3. Use the pch argument to par to set the plotting
#    character to 19.

# 4. Plot x.

# 5. Now set the plotting character to 23 and the
#    plotting colour to "darkred" (the argument to par()
#    for setting the colour is col).

# 6. points() is used to add points to an existing
#    plot. Use points to add points for x/2 to the plot.

# 7. Use points to add points for x/1.75 to the plot
#    but this time use the argument col = "darkgreen" as
#    well so that they get rendered in dark green.
