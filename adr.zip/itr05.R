###############################################
### Variables, names, symbols and, bindings ###
###############################################

# Variables are objects.

# Symbols (or names) are handles or labels for variables
# through which we can access the variables.

# After an assignment like: x <- 42

#     the name "x" has the value 42.

#     the value 42 has a label attached to it with "x"
#     written on it

#     The symbol "x" is bound to the value 42.

#     Assuming a clean session of R, the symbol "y" is
#     unbound.

# Don't imagine x to be a container containing the value 42.

# Objects live in memory and have memory addresses. Symbols
# let us refer to variables much more easily than would be
# possible through memory addresses.

# Nothing prevents two symbols from refering to the same
# memory address. In fact this is what happens after

y <- x;

# What happens when rm is invoked?

rm(x);


# On a given machine, memory addresses are unique, but
# variable names are not. Within one session of R you can
# have more than one variables named "x" and the right one
# should be used everytime we refer to "x".
