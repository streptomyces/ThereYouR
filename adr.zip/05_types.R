########################
### Basic data types ###
########################

# Character (strings of characters)
# Numeric
  ## Integers
  ## Double (double precision floating point numbers)
# Logical. Boolean. TRUE or FALSE only.
# Complex
# Raw

# We will not using the Complex and Raw types.

# We don't have to worry whether our numeric variables are
# integers or doubles, except when it does matter!

# Explain x <- 42L

x <- 42;

y <- 42L;

typeof(x);

typeof(y);

# It is not possible to make a variable of one of the basic
# data types. You can only have vectors of these types.

