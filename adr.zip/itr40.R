########################
### Closing comments ###
########################

# R is not the most convenient environment for all kinds
# of data processing.

# Some things might be easier to do in a general purpose
# programming language such as Perl or Python.

# You can find plenty of help and support for Python and
# Perl around the NRP.

# If you are good at learning on your own, or can find
# someone to learn with, then consider Julia very seriously.

# Like any other skill, the best way to maintain and
# advance your R skills is by using it regularly. Try to get
# together with a friend and use R regularly. You will learn
# a lot faster if you practice in pairs. 

# Ability to read documentation quickly is more important
# than you think. Not just in R.

# R manuals webpage.
# https://cran.r-project.org/manuals.html

# PDF of the Introduction to R book.
# https://cran.r-project.org/doc/manuals/r-release/R-intro.pdf

# Tidyverse (dplyr, tibbles, ggplot and more) documentation.
# https://www.tidyverse.org/

# RNA-Seq data analysis using edgeR.
# https://f1000research.com/articles/5-1438
