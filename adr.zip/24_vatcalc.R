
# R provides "if" for branching in functions.

x <- 42L;
if(x == 42) {
  cat("\nWelcome to the intergalactic warpcraft!\n");
} else {
  cat("\nGrow your own wings!!\n");
}



vat <- function(x = 100, add = TRUE, rate = 20) {
  if(add) {
    vatplus <- x + x * (rate / 100);
    return(vatplus);
  } else {
    vatminus = x / (1 + (rate / 100));
    return(vatminus);
  }
}


