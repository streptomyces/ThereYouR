
# R provides "if" for branching in functions.

x <- 42L;
if(x == 42) {
  cat("\nWelcome to the intergalactic warpcraft!\n");
} else {
  cat("\nGrow your own wings!!\n");
}

#################################
### Do the following yourself ###
#################################

# Write a function named vat, which takes three arguments.

# vat <- function(x = 100, add = TRUE, rate = 20)

# to return the amount before or after VAT depending upon
# whether the argument add is TRUE or FALSE. x is the amount
# and rate is the VAT rate in percent.

# All three arguments have default values so that when
# called without any arguments it should return 120.

