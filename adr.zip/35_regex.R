###########################
### Regular Expressions ###
###########################

# Suppose we want all genes with logFC more than 2.5 AND which
# are not "hypothetical proteins".

notHypoth2.5 <- data[
  abs(data$logFC) >= 2.5 &
    data$product != "hypothetical protein"
  , ];

head(notHypoth2.5);
nrow(notHypoth2.5);


# In reality the situation is usually not so simple.

# There might be more than one space between "hypothetical" and
# "protein"?

# Inconsistent capitalisation, e.g. "hypothetical" starting with
# a capital "H".

# Alternative spellings.

# Most characters in a RE match themselves but some have special
# meanings.

# To use the special ones literally you need to escape them with
# "\". e.g. \$ for the dollar symbol.

### Quantifiers ###

# ?     Zero or once.                              
# *     Zero or more.                              
# +     Once or more.                              
# {n}   Exactly n times.                           
# {m,n} At least m times but no more than n times. 
# {m,}  At least m times.                          


### Metacharacters ###
 
# .   Any character                               
# ^   Beginning of the string.                    
# $   End of the string.                          


### Character classes ###

# []  Group of characters e.g. [A-Z].             
# [^] Not in the group of characters e.g. [^0-9]. 

### Abbreviations ###

# \s   Any white space [ \t\n\r\f]
# \d   Any digit [0-9]
# \w   Any word character [0-9a-zA-Z_]
# There are others.

f <- c(
"favourite colour",
"Favourite Colour",
"favorite color",
"favorite colored dress",
"favourite  coloured dress",
"nice colored dress"
);

# The indexes which match.
grep("colour", f);
str_which(f, "colour");

# The values which match.
grep("colour", f, value = TRUE);
str_subset(f, "colour");

# One or zero 'u'.
grep("colou?r", f, value = TRUE);
str_subset(f, "colou?r");

# $ to anchor match at end of string.
grep("colou?r$", f, value = TRUE);
str_subset(f, "colou?r$");

grep("favou?rite colou?r$", f, value = TRUE);
str_subset(f, "favou?rite colou?r$");

# + after the space mean one or more spaces.
# And, case-insensitive matching.
grep("favou?rite +colou?r", f, value = TRUE, ignore.case = TRUE);
str_subset(f, regex("favou?rite +colou?r", ignore_case = TRUE));

# using \s for space. Otherwise same as above.
grep("favou?rite\\s+colou?r", f, value = TRUE, ignore.case = TRUE);
str_subset(f, regex("favou?rite\\s+colou?r", ignore_case = TRUE));

# logical (TRUE or FALSE) output.
grepl("favou?rite\\s+colou?r", f, ignore.case = TRUE);
str_detect(f, regex("favou?rite\\s+colou?r", ignore_case = TRUE));

# Substitution
spacefixed <- gsub(" {2,}", " ", f);
spacefixed1 <- str_replace_all(f, " {2,}", " ");

spellfixed <- gsub("vori", "vouri", spacefixed);
spellfixed1 <- str_replace_all(spacefixed, "vori", "vouri");

selector <- !grepl(
"hypothetical +protein",
data$product, ignore.case = TRUE);

selector <- !str_detect(data$product,
regex("hypothetical +protein", ignore_case = T));


notHypoth2.5 <- data[abs(data$logFC) >= 2.5
& selector , ]

nrow(notHypoth2.5)
head(notHypoth2.5)
min(abs(notHypoth2.5$logFC))

# There is a lot more to regular expressions than we
# have demonstrated above. They are a truly general
# purpose high value skill to acquire. All programming
# languages worth learning / using have them in some
# form or another.

### Some useful regular expression related functions in
### R.

# grep()
# regexpr()
# gregexpr()
# sub()
# gsub()
# And the alternatives in the package stringr of Tidyverse.
