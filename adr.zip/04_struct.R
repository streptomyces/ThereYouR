#######################
### Data structures ###
#######################

# Most analyses in R start with reading some data into R.

# Collections of the basic data types.

# Several data structures are provided in R as classes.

# It is possible to make your own but we will not be doing
# so. The ones provided are sufficient for what we do.

# They range in complexity and flexibility.

# Reading data from a text file.
vnz.df <- read.csv("data/vnz_genes.csv", header = T,
stringsAsFactors = F)

# Writing data to a text file.
write.csv(vnz.df, "out/vnz_genes.csv", quote = F,
row.names = F);

### Tidyverse style ###

# Reading data from a text file.
vnz.tib <- read_csv("data/vnz_genes.csv");

# Writing data to a text file.
write_csv(vnz.tib, "out/vnz_genes.csv",
quote_escape = "none")

