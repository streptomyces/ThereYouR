# Advanced R 30 Jan and 1 Feb 2023

As soon as you arrive on the first day

1. Login on one the PCs in the training
theatre.

2. Start a web browser and point it to the URL shown
below.

### https://streptomyces.github.io/ThereYouR/

## Some requests

* Please put your mobile phones away.
There is a break every 90 minutes, you can use them then.

* Things get complicated as we proceed further into the course.
So please ask if something is not clear.

## Timings for both Mon 30 Jan and Wed 1 Feb 2023

~~~ 
Course                       0930  to   1100
Coffee break                 1100  to   1130
Course                       1130  to   1300
Lunch (not provided)         1300  to   1400
Course                       1400  to   1530
Coffee break                 1530  to   1600
Course                       1600  to   1730
~~~

## Before we start

* Who are we.

* The focus of this course is on R syntax and
  techniques, not statistics.


## How will this course work?

- I will introduce methods by talking about them.

- You will run some commands along with me to see the
  methods in action.

- I will explain the commands and the syntax you have
  just seen in action.

### Sometimes there will be things for you to do on your own.

+ These tasks will be described in semi-plain english.

+ You will have to think how to do them in R using as many
steps and variables as you need.

+ Finally, I will show you how I would have done the tasks.
There are (almost always) more than one ways to do it. 
Your way of doing things might be different from mine but
correct nevertheless.

## Things mentioned below will be done during the course
### Please don't do them before hand. 

#### Getting the scripts and data we will be using during the course

In Rstudio, use the drop down menu to do

    File -> New File -> R Script

In the blank R script we will write and run
the indented lines shown below. Please do this
with me. Resist the temptation to charge ahead.

~~~ {.r}
    setwd("u:/")
    unlink("Rtrain", recursive = TRUE)
    dir.create("Rtrain")

    setwd("Rtrain")

    getwd()

    unlink("*")

    list.files()
    
    download.file("https://github.com/streptomyces/ThereYouR/raw/master/adr.zip", 
    "adr.zip")

    list.files()

    unzip("adr.zip")

    list.files()
~~~
