#####################
### Rounding etc. ###
#####################

# round()
pi
round(pi)
round(pi, 3);

# signif()
signif(pi)
signif(pi, 6);
signif(pi, 3);

# floor()
floor(pi)

# ceiling()
ceiling(pi)
