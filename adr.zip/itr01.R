#######################
### Data structures ###
#######################

# Most analyses in R start with reading some data into R.

w <- read.csv("data/owid-covid-data.csv"); 

# Collections of the basic data types.

# Several data structures are provided in R as classes.

# It is possible to make your own but we will not be doing
# so. The ones provided are sufficient for what we do.

# They range in complexity and flexibility.

uk <- filter(w, str_detect(location,
regex("united kingdom", ignore_case = T))
);

ukk <- w[grepl("united kingdom",
w$location, ignore.case = T),]


