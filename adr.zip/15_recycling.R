######################################
### Recycling in Vector operations ###
######################################


#################################
### Do the following yourself ###
#################################

# 1. Assign the sequence from 1 to 5 to x.
# 2. Assign the sequence 21 to 25 to y.
# 3. Examine the result of y * x.

#############################################################
  
# 4. Assign the sequence 21 to 30 to z.
# 5. Confirm the lengths of x and z using the function length().
# 6. Examine the result of z * x.

#############################################################
  
# 7. Assign the sequence from 1 to 7 to u.
# 8. Examine the result of z * u.

#############################################################
#############################################################
# In operations involving two vectors of unequal length, elements of the
# shorter vector get recycled.
# If the longer vector is not an integer multiple of the shorter vector
# you get a warning but the operation is valid and successful.
