################
### Matrices ###
################

# Like data frames, these are two dimensional tables with rows and
# columns.

# All elements in a matrix have to be of the same type.

### Making a matrix by using matrix().

x <- seq(1,50);
x;

m <- matrix(x, nrow = 5, ncol = 10);

rownames(m) <- paste("R", seq(1, 5), sep = "");
colnames(m) <- paste("C", seq(1, 10), sep = "");

rownames(m);
colnames(m);


### Making a matrix by adding the dim attribute to a vector.

m <- seq(51,100);
dim(m) <- c(5,10);
m;

attributes(m);
class(m);

rn <- paste("R", seq(1, 5), sep = "");
cn <- paste("C", seq(1, 10), sep = "");
dimnames(m) <- list(rn, cn);

attributes(m);
str(m);
