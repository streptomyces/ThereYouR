###########################
### Subsetting matrices ###
###########################

# matrix[rownum, colnum]

# If you do not specify any rows to get, you get all rows.

# If you do not specify any columns to get, you get all columns.

# Just like subsetting data frames, except that if you ask for a single
# row you get a vector.

m[1,2];

m["R1", "C2"];

row3 <- m[3,]; row3;

class(row3);

col1 <- m[, 1]; col1;

class(col1);

### Using more than one rows and columns for subsetting a matrix

# To extract any arbitrary part of your matrix as a matrix you
# may use vectors of rownums and colnums as below.

m[c(2,3), c(2,4)];

s <- m[c("R2","R3"), c("C2", "C4")];

s;

class(s);

attributes(s);

#################################
### Do the following yourself ###
#################################

# 1. Store the sequence 1 to 28 to a vector d.

# 2. Use matrix() to make a matrix x from d having 7 columns and
#    4 rows such that the first row reads 1,2,3,4,5,6,7 as shown
#    below. Refer to the help of matrix() to find out the named
#    argument you need to use.

#   1    2    3    4    5    6    7
#   8    9   10   11   12   13   14
#  15   16   17   18   19   20   21
#  22   23   24   25   26   27   28

# 3. Set the column names to Mon, Tue, Wed...

# 4. Set the row names to Week1, Week2, Week3...

# 5. Examine the matrix x.

#       Mon Tue Wed Thu Fri Sat Sun
# Week1   1   2   3   4   5   6   7
# Week2   8   9  10  11  12  13  14
# Week3  15  16  17  18  19  20  21
# Week4  22  23  24  25  26  27  28

# 6. Extract the date on the Friday of the third week.
# 7. Store all the dates falling on Wednesday to wed.
# 8. Examine wed.
