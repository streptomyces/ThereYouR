###############
### ggplot2 ###
###############

# Part of a collection of packages called tidyverse.

# The "gg" in ggplot2 stands for Grammar of Graphics.

# Much more structured and formal than the collection of
# graphics commands in base R.

### Three essential components of a ggplot ###

# 1. Data. Usually a dataframe or a tibble.

# 2. Aesthetic mappings. Think of them as mapping of
# data to axes and colour and shape of points. Function:
# aes().

# 3. Layers. Actual rendering on the plotting device.
# Functions: geom_*(). The kind of plot you want.
# Multiple layers are allowed and indeed, common.

### Function ggplot() ###

# Usually called with two arguments, data and aesthetic
# mapping.

# Data, of course, is your dataframe and you get an
# aesthetic mapping by calling aes(). Calls to aes() can
# be used as argument to ggplot() or to geom_*(). If
# included in ggplot() the values are inherited by all
# layers.

### Layers ###

# To the result of the call to ggplot() we can add
# layers.

### Theme ###

# Function theme().

# Control the overall appearance of a plot.

rm(list = ls());
df <- read.csv("data/tfaG.csv");
head(df);

# This is not the best way to organise your data for
# ggplot2. If you have a dataframe like.

#   hour       wt     tfaG
# 1    1 2.597158 2.830137
# 2    2 2.636187 2.800135
# 3    3 2.837971 2.917881
# 4    4 2.711013 2.703749
# 5    5 2.882070 2.838809
# 6    6 2.724614 2.028673


# Reform it to something like this.

#     hour strain  logexpr
# 1      1     wt 2.597158
# 2      2     wt 2.636187
# 3      3     wt 2.837971
# ...
# 118   58   tfaG 2.246144
# 119   59   tfaG 2.755333
# 120   60   tfaG 2.775126

# Think like this: everything on the x-axis goes in one
# column no matter how many categories those values
# belong to. The categories can be specified in other
# columns. Similarly for the values intended for the
# y-axis. This is often referred to as the "tidy" data
# format.

# Below is one way of getting from df to gdf.

gdf <- data.frame(hour = rep(df$hour, 2),
      strain = c(rep(colnames(df)[2], nrow(df)),
      rep(colnames(df)[3], nrow(df))),
      logexpr = c(df$wt, df$tfaG)
)
head(gdf)
class(gdf$strain)

### Plotting begins ###

p1 <- ggplot(gdf, aes(x = hour, y = logexpr, colour = strain)) +
  geom_point() +
  geom_path()

# Axis labels xlab(), ylab()
# expression(); help("plotmath");

l2e <- expression(log[2]~Expression); # help("plotmath");
p1 + xlab("Hours of growth") + ylab(l2e);

# Theme
p1 + theme_bw()

p2 <- ggplot(gdf, aes(hour, logexpr, colour = strain,
              shape = strain)) +
              geom_point(size = 3) +
              geom_path(size = 1.2)


# Plotting colours and legend
gdfcols <- c("#129628", "#961254");
p3 <- p2 + scale_colour_manual(name = "Strain id",
values = c(gdfcols),
aesthetics = c("colour", "fill"),
labels = c("tfaG deletion strain", "M600")) +
scale_shape_discrete(name = "Strain id",
labels = c("tfaG deletion strain",
"M600")) + theme_bw() +
xlab("Hours of growth") + ylab(l2e);

# Main title
plot.title <- c("Expression of SpoF in M600 and tfaG");
plot.title <- paste(plot.title, "deletion strains\nover 60");
plot.title <- paste(plot.title, "hours of growth in shaken flask");

p4 <- p3 + ggtitle(plot.title);

# Theme
p5 <- p4 +
  theme_bw() +
  theme(plot.title = element_text(size = 24, face = "bold",
                                  hjust = 0.5)) +
  theme(axis.title = element_text(size = 18, face = "bold",
                                  vjust = 0.5)) +
  theme(axis.text = element_text(size = 15, face = "plain",
                                 vjust = 0.5)) +
  theme(legend.text = element_text(size = 15, face = "bold",
                                   hjust = 0.5)) +
  theme(legend.key.size = unit(15, "mm")) +
  theme(legend.title = element_text(size = 18, face = "bold",
                                    hjust = 0.5)) +
  theme(plot.margin = margin(1, 1, 1, 1, "cm")) +
  theme(panel.grid = element_blank())

p5
ggsave("out/expression.pdf", p5)
ggsave("out/expression.png", p5)

## p + xlim(5, 20) + ylim(0, 50)

