######################################
### Recycling in Vector operations ###
######################################


#################################
### Do the following yourself ###
#################################

# 1. Store the sequence from 1 to 5 in vector x.
# 2. Store the sequence from 21 to 25 in vector y.
# 3. Examine the result of y * x.

#############################################################
  
# 4. Store the sequence from 21 to 30 in vector z.
# 5. Confirm the lengths of x and z using the function length().
# 6. Examine the result of z * x.

#############################################################
  
# 7. Store the sequence from 1 to 7 in vector u.
# 8. Examine the result of z * u.



#############################################################
#############################################################
# In operations involving two vectors of unequal length, elements of the
# shorter vector get recycled.
# If the longer vector is not an integer multiple of the shorter vector
# you get a warning but the operation is valid and successful.
#############################
### Some Common Functions ###
#############################

# c(): concatenate.

x <- c(2.17, 3.14, 13, 29, 48.356);
y <- c(200,300);
z <- c(x, y);
z;

# length(): Return the length of the named object.
length(x);
length(y);

# min() and max(): Minimum / Maximum element of an object.
min(x);
min(y);

# mean() and median():
mean(x);
median(y);

# summary(): Some key statistics about an object.
summary(y);
